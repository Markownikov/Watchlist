 <reference types="vite/client" />
